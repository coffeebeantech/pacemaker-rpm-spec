pacemaker_binaries = "/usr/sbin/"
corosync_binaries = "/usr/sbin/"
corosync_conf_file = "/etc/corosync/corosync.conf"
fence_agent_binaries = "/usr/sbin/"
